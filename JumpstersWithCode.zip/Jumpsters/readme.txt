"Jumpsters" is an action game that requires specific skills from a player. (easy to learn, hard to master)
To beat the game player must survive for two minutes while dodging enemies by bouncing and collecting bonuses.
The longer the player plays, the harder it gets. Moreover, every 10 seconds a player will receive an additional bonus to score (depending on how long a player will survive).
The game ends when a player touches an enemy or ends a number of available jumps.
To get more jumps player must to collect bananas. Apples give more score bonus, melons give a protection shield for a time (depending on level upgrades, max is 5)
Player can buy upgrades and skins. All progress will be saved to the file "data.txt" (even last equipped skin).

Controls:
RIGHT, LEFT ARROW KEYS - to move.
LEFT CLICK - to use buttons.
ESC - to exit.