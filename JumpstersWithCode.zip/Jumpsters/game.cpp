#include <iostream>
#include <fstream> 
#include <vector>
#include "game.h"
#include "surface.h"
#include "template.h"
#include <stdlib.h>
#include "time.h"    
#include <windows.h>
#include <mmsystem.h>
#include <cstdio> //printf
#include <SDL_events.h>
using namespace std;

namespace Tmpl8
{
	enum Gamemode {
		Game_over,
		Game_menu,
		Game_shop,
		Game_gameplay,
		Game_win
	};

	struct ShopData
	{
		int skins[4] = { 2, 0, 0, 0 }; // 0 - not bought, 1 - bought but not equiped, 2 - bought and equiped
		int speedLvl = 1, startJumpLvl = 1, bonusJumpLvl = 1, bonusScoreLvl = 1, bonusShieldTimeLvl = 1;
	};

	struct GameData {
		int enemies = 2, timer = 120;
		int frame = 0, frameTime = 0;
		char DeathMessage[128];
	};

	struct Enemy {
		bool died = false;
		bool isMovingLeft = true;
		int speed = 3, x = 900, y = 512 - 30;
		int gravitySpeed = 2;
	};

	struct Buttom {
		int x = ScreenWidth / 2, y = ScreenHeight / 2;
	};

	struct Player {
		bool shieldIsActive = false;
		int jumpLeft = 20, movementSpeed = 5, speed = 1, score = 0, ground = 1;
		int X = 0, Y = 370;
		int limitY = 200;
		int coins = 0;
		int bestScore = 0;
	};

	struct Bonus {
		bool hasCooldown = false;
		int durationTime = 2 * 60, timeLeft = 0, couldown = 0;
		int x = rand() % 736 + 32, y = 480;
		int bonusJumpsAdd = 50;
	};

	struct Sounds {
		bool isPlayed = false;
		int op[100] = {0}; //options
	};
	
	void collisions(GameData& game, Player& player, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee);
	void playerJumps(Player& player);
	void resetGame(GameData& game, ShopData shopData, Player& player, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee);
	void spawnBonuses(GameData game, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus);
	void spawnEnemies(GameData game, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee);
	
	Gamemode Current_gm;
	vector <Enemy> bat;
	vector <Enemy> pig;
	vector <Enemy> bee;
	vector <Bonus> jumpBonus;
	vector <Bonus> scrBonus; 
	vector <Bonus> sdBonus;
	Sounds menuSounds;
	ShopData shopData;
	GameData game;
	Player player;

	void Game::Shutdown()	// Close down application //pickup animation
	{
		fstream fd("data.txt");
		printf("speedLvl: %d.\n", shopData.speedLvl);
		for (int i = 0; i < 4; i++) fd << shopData.skins[i] << " "; //4 skins
		fd << shopData.speedLvl << " " << shopData.startJumpLvl << " " << shopData.bonusJumpLvl << " " << shopData.bonusScoreLvl << " " << shopData.bonusShieldTimeLvl << endl;
		fd << player.coins << " " << player.bestScore << endl;
		fd.close();
	}

	void Game::Init()	// Initialize the application
	{
		fstream fd("data.txt");
		for (int i = 0; i < 4; i++) fd >> shopData.skins[i]; //4 skins
		fd >> shopData.speedLvl >> shopData.startJumpLvl >> shopData.bonusJumpLvl >> shopData.bonusScoreLvl >> shopData.bonusShieldTimeLvl;
		fd >> player.coins >> player.bestScore;
		fd.clear();

		srand(time(NULL));
		Current_gm = Game_menu;
	}

	//---- Backgrounds ----
	Sprite pinkBg(new Surface("assets/Pixel_adventure/Background/Pink.png"), 1);
	Sprite brownBg(new Surface("assets/Pixel_adventure/Background/Brown.png"), 1);
	Sprite greenBigBg(new Surface("assets/Pixel_adventure/Background/BigGreen.png"), 1);
	//---- Enemies ----
	Sprite enemyPig(new Surface("assets/Pixel_adventure/Enemies/AngryPig/Run.png"), 12);
	Sprite enemyPigReverse(new Surface("assets/Pixel_adventure/Enemies/AngryPig/RunReverse.png"), 12);
	Sprite enemyBat(new Surface("assets/Pixel_adventure/Enemies/Bat/Flying.png"), 7);
	Sprite enemyBatReverse(new Surface("assets/Pixel_adventure/Enemies/Bat/FlyingReverse.png"), 7);
	Sprite enemyBee(new Surface("assets/Pixel_adventure/Enemies/Bee/Idle.png"), 6);
	//---- Bonuses ----
	Sprite scoreBonus(new Surface("assets/Pixel_adventure/Items/Fruits/Apple.png"), 17);
	Sprite timeBonus(new Surface("assets/Pixel_adventure/Items/Fruits/Bananas.png"), 17);
	Sprite shieldBonus(new Surface("assets/Pixel_adventure/Items/Fruits/Melon.png"), 17);
	Sprite shieldCircle(new Surface("assets/Pixel_adventure/Items/Shield.png"), 1);
	//---- Buttons ----
	Sprite Play_buttom(new Surface("assets/Pixel_adventure/Menu/Buttons/Play.png"), 1);
	Sprite shopButtom(new Surface("assets/Pixel_adventure/Menu/Buttons/Shop.png"), 1);
	Sprite exitButtom(new Surface("assets/Pixel_adventure/Menu/Buttons/Exit.png"), 1);
	Sprite backToMenuButtom(new Surface("assets/Pixel_adventure/Menu/Buttons/Previous.png"), 1);
	Sprite restartButtom(new Surface("assets/Pixel_adventure/Menu/Buttons/Restart.png"), 1);
	Sprite plusButtom(new Surface("assets/Pixel_adventure/Menu/Buttons/Plus.png"), 1);
	//---- Skins ----
	Sprite theSprite(new Surface("assets/Pixel_adventure/Main_Characters/CharactersFallAndJump.png"), 16);
	Sprite firstSpriteShop(new Surface("assets/Pixel_adventure/Main_Characters/Ninja_Frog/Idle (32x32).png"), 11);
	Sprite secondSpriteShop(new Surface("assets/Pixel_adventure/Main_Characters/Mask_Dude/Idle (32x32).png"), 11);
	Sprite thirdSpriteShop(new Surface("assets/Pixel_adventure/Main_Characters/Pink_Man/Idle (32x32).png"), 11);
	Sprite fourthSpriteShop(new Surface("assets/Pixel_adventure/Main_Characters/Virtual_Guy/Idle (32x32).png"), 11);
	//---- Platforms ----
	Sprite longPlatform(new Surface("assets/Pixel_adventure/Terrain/Long_PlatformTest.png"), 1); // 232 , 5
	Sprite longPlatformWithHole(new Surface("assets/Pixel_adventure/Terrain/Long_Platform_With_Hole.png"), 1); // 232 , 5 (hole 92 ; 5 to 139 ; 5)

	const int lpX = 800 - 232, lpY = ScreenHeight / 2; // longPlatform
	const int lpwhX = ScreenWidth / 2 - 116, lpwhY = ScreenHeight / 2 + 110; //longPlatformWithHole
	bool lastButtonRight = true;
	int SaveScore = 0;
	int bgY = 0;

	void Game::Tick(float deltaTime)	// Main application tick function
	{
		game.frameTime++;

		if (Current_gm == Game_gameplay) {
			screen->Clear(100); // clear the graphics window

			game.frame++; // Actual Game Frame

			//--- Moving background ---
			greenBigBg.Draw(screen, 0, bgY);
			bgY--;
			if (bgY <= -512) bgY = 0;

			//--- Game Timer ---
			if (game.frameTime % 60 == 0) game.timer--;
			if (game.timer % 10 == 0 && game.timer !=120 && game.timer != 0) player.score +=  (120 - game.timer) / 10; //bonus for surviving


			//--- Printing Stats ---
			char playerStatusText[128];
			char timerText[128];
			char playerScore[128];
			sprintf(playerStatusText, "Jumps Left: % d\n", player.jumpLeft);
			sprintf(timerText, "Time left: %d:%d", game.timer/60, game.timer%60);
			sprintf(playerScore, "Score: %d", player.score);
			if (player.jumpLeft > 25) screen->Print(playerStatusText, 5, 20, 0xffffff);
			else if (player.jumpLeft >= 15) screen->Print(playerStatusText, 5, 20, 0xffff00);
			else screen->Print(playerStatusText, 5, 20, 0xff0000);
			screen->Print(timerText, 702, 5, 0xffffff);
			screen->Print(playerScore, 5, 5, 0xffffff);
			/*char text[128];
			sprintf(text, "X - position: % d\nY - position: % d\nSpeed: % d\nGround: % d\n", player.X, player.Y, player.speed, player.ground);
			screen->Print(text, 5, 35, 0xffffff); // print something in the graphics window*/

			//--- Player Movement ---
			if (GetAsyncKeyState(VK_LEFT)) lastButtonRight = false, player.X -= player.movementSpeed;
			if (GetAsyncKeyState(VK_RIGHT)) lastButtonRight = true, player.X += player.movementSpeed; //if (GetAsyncKeyState(VK_UP)) spriteY-= speed; //if (GetAsyncKeyState(VK_DOWN)) spriteY+= speed;

			//--- Player Screen Border ---
			if (player.X < 0) player.X = 0;
			else if (player.X > 800 - 32) player.X = 800 - 32;

			//--- Sprite Frame Changing ---
			timeBonus.SetFrame(game.frame % 17);
			scoreBonus.SetFrame(game.frame % 17);
			shieldBonus.SetFrame(game.frame % 17);
			enemyPig.SetFrame(game.frame / 2 % 12);
			enemyPigReverse.SetFrame(game.frame / 2 % 12);
			enemyBat.SetFrame(game.frame / 4 % 7 );
			enemyBatReverse.SetFrame(game.frame / 4 % 7);
			enemyBee.SetFrame(game.frame / 4 % 6);

			for (int i = 0; i < 4; i++) //Fall and Jump skins sprite detecor and activator
			{
				if (shopData.skins[i] == 2)
				{
					if (player.speed >= 0 && lastButtonRight == true) theSprite.SetFrame(0 + 4 * i);
					else if (player.speed < 0 && lastButtonRight == true) theSprite.SetFrame(1 + 4 * i);
					else if (player.speed < 0 && lastButtonRight == false) theSprite.SetFrame(2 + 4 * i);
					else  theSprite.SetFrame(3 + 4 * i);
				}
			}

			player.Y += player.speed; // Player gravity speed
			player.speed += 1;
			if (player.speed >= 18) player.speed = 18; // constant max speed;

			spawnBonuses(game, scrBonus, jumpBonus, sdBonus);
			spawnEnemies(game, pig, bat, bee);
			playerJumps(player);
			collisions(game, player, scrBonus, jumpBonus, sdBonus, pig, bat, bee);

			//--- Enemies Movement ---
			for (int i = 0; i < pig.size(); i++)
			{
				if (pig[i].isMovingLeft == true) pig[i].x -= pig[i].speed;
				else pig[i].x += pig[i].speed;
			}
			for (int i = 0; i < bat.size(); i++)
			{
				if (bat[i].isMovingLeft == true) bat[i].x -= bat[i].speed;
				else bat[i].x += bat[i].speed;
			}
			for (int i = 0; i < bee.size(); i++)
			{
				bee[i].x -= bee[i].speed;
				bee[i].y -= bee[i].gravitySpeed;
				bee[i].gravitySpeed += 1;
				if (bee[i].gravitySpeed >= 24) bee[i].gravitySpeed = 24;
				if (bee[i].y < 0)
				{
					bee[i].y = 0;
					bee[i].gravitySpeed = -bee[i].gravitySpeed;
				}
			}

			//--- Shield Bonus Duration ---
			for (int i = 0; i < sdBonus.size(); i++)
			{
				if (sdBonus[i].timeLeft > 0) sdBonus[i].timeLeft--;
				else if (sdBonus[i].couldown > 0)
				{
					sdBonus[i].couldown--;
					player.shieldIsActive = false;
				}
				else
				{
					sdBonus[i].hasCooldown = false;
					player.shieldIsActive = false;
				}
			}

			//--- Drawing Sprites ---
			longPlatformWithHole.Draw(screen, lpwhX, lpwhY);  // draw a sprite
			longPlatform.Draw(screen, 0, ScreenHeight / 2);
			longPlatform.Draw(screen, 800-232-47, ScreenHeight / 2);
			theSprite.Draw(screen, player.X, player.Y);
			if (player.shieldIsActive == true) shieldCircle.Draw(screen, player.X, player.Y);
			for (int i = 0; i < jumpBonus.size(); i++) timeBonus.Draw(screen, jumpBonus[i].x, jumpBonus[i].y);
			for (int i = 0; i < scrBonus.size(); i++) scoreBonus.Draw(screen, scrBonus[i].x, scrBonus[i].y);
			for (int i = 0; i < sdBonus.size(); i++) if (sdBonus[i].hasCooldown == false && sdBonus[i].couldown <= 0) shieldBonus.Draw(screen, sdBonus[i].x, sdBonus[i].y);
			for (int i = 0; i < pig.size(); i++)
			{
				if (pig[i].isMovingLeft == true) enemyPig.Draw(screen, pig[i].x, pig[i].y);
				else enemyPigReverse.Draw(screen, pig[i].x, pig[i].y);
			}
			for (int i = 0; i < bat.size(); i++) 
			{	
				if (bat[i].isMovingLeft == true) enemyBat.Draw(screen, bat[i].x, bat[i].y);
				else enemyBatReverse.Draw(screen, bat[i].x, bat[i].y);
			}
			for (int i = 0; i < bee.size(); i++) enemyBee.Draw(screen, bee[i].x, bee[i].y);


			if (player.jumpLeft <= 0) //Game over if left player jumps = 0;
			{
				sprintf(game.DeathMessage, "Endend the number of jumps! (Eat more bananas!)");
				Current_gm = Game_over;
				game.frame = 0;
				player.X = 0, player.Y = 300;
				player.jumpLeft = 10;
			}

			if (game.timer <= 0)//Win condition
			{
				Current_gm = Game_win;
			}

			mouse_pressed = 0;
		}
		else if (Current_gm == Game_menu)
		{
			game.frame = 0;
			Buttom play, shop, exit;
			shop.y -= 25;
			exit.y += 25;
			screen->Clear(0);

			//--- Background ---
			for (int x = 0; x < ScreenWidth; x += 64)
			{
				for (int y = 0; y < ScreenHeight ;y += 64) pinkBg.Draw(screen, x, y);
			}

			//--- Changing Data ---
			player.movementSpeed = 4 + shopData.speedLvl;
			player.jumpLeft = 10 + shopData.startJumpLvl * 10;

			//--- Printing Data ---
			char text[128];
			char PlayerCoinsText[128];
			sprintf(text, "This is Menu, click Play button to start the game.");
			sprintf(PlayerCoinsText, "Coins: %d \n Best Score: %d", player.coins, player.bestScore);
			Play_buttom.Draw(screen, play.x, play.y);
			shopButtom.Draw(screen, shop.x, shop.y);
			exitButtom.Draw(screen, exit.x, exit.y);
			screen->Print(text, 5, 5, 0xffffff);
			screen->Print(PlayerCoinsText, 5, 20, 0xffff00);
			/*char MouseText[128];
			sprintf(MouseText, "X - position: % d\nY - position: % d\n", mousex, mousey);
			sprintf(text, "This is Menu, click Play button to start the game. % d\n", mouse_pressed);
			//screen->Print(MouseText, 20, 20, 0xffffff);*/

			//--- Buttons Detector With A Mouse ---
			if (mouse_pressed == 1 && mousex <= play.x + 20 && mousex >= play.x && mousey <= play.y + 20 && mousey >= play.y) mouse_pressed = 0, Current_gm = Game_gameplay;
			else if (mousex <= play.x + 20 && mousex >= play.x && mousey <= play.y + 20 && mousey >= play.y)
			{
				if (menuSounds.op[0] == 0)
				{
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
					memset(menuSounds.op, 0, sizeof(menuSounds.op));
					menuSounds.op[0] = 1;
				}
				screen->Print("Play", play.x + 30, play.y + 10, 0xffffff);
				mouse_pressed = 0;
			}
			else if (mouse_pressed == 1 && mousex <= shop.x + 20 && mousex >= shop.x && mousey <= shop.y + 20 && mousey >= shop.y) mouse_pressed = 0, Current_gm = Game_shop;
			else if (mousex <= shop.x + 20 && mousex >= shop.x && mousey <= shop.y + 20 && mousey >= shop.y)
			{
				if (menuSounds.op[1] == 0)
				{
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
					memset(menuSounds.op, 0, sizeof(menuSounds.op));
					menuSounds.op[1] = 1;
				}
				screen->Print("Shop", shop.x + 30, shop.y + 10, 0xffffff);
				mouse_pressed = 0;
			}
			else if (mouse_pressed == 1 && mousex <= exit.x + 20 && mousex >= exit.x && mousey <= exit.y + 20 && mousey >= exit.y)
			{
				//End the game
				mouse_pressed = 0;
				SDL_Event quit{ SDL_QUIT };
				SDL_PushEvent(&quit);
			}
			else if (mousex <= exit.x + 20 && mousex >= exit.x && mousey <= exit.y + 20 && mousey >= exit.y)
			{
				if (menuSounds.op[2] == 0)
				{
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
					memset(menuSounds.op, 0, sizeof(menuSounds.op));
					menuSounds.op[2] = 1;
				}
				screen->Print("Exit", exit.x + 30, exit.y + 10, 0xffffff);
				mouse_pressed = 0;
			}
			else
			{
				memset(menuSounds.op, 0, sizeof(menuSounds.op));
				mouse_pressed = 0;
			}
		}
		else if (Current_gm == Game_over)
		{
			screen->Clear(0);
			resetGame(game, shopData, player, scrBonus, jumpBonus, sdBonus, pig, bat, bee);

			//--- Saving Score ---
			if (player.score > 0) SaveScore = player.score;
			player.coins += player.score / 100;
			if (player.score > player.bestScore) player.bestScore = player.score;
			player.score = 0;

			//--- Printing Data ---
			char coins[128];
			char resultText[128];
			sprintf(resultText, "Your score: %d", SaveScore);
			sprintf(coins, "That is %d coins!", SaveScore / 100);
			restartButtom.Draw(screen, ScreenWidth / 2, ScreenHeight / 2);
			backToMenuButtom.Draw(screen, ScreenWidth / 2, ScreenHeight / 2 + 30);
			screen->Print(game.DeathMessage, ScreenWidth / 2 - 100, ScreenHeight / 2 - 40 , 0xffffff);
			screen->Print(resultText, ScreenWidth / 2 - 35, ScreenHeight / 2 - 30, 0xffffff);
			screen->Print(coins, ScreenWidth / 2 - 40, ScreenHeight / 2 - 20, 0xffff00);

			//--- Buttons Texts Detector With A Mouse ---
			if (mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2) + 20 && mousey >= (ScreenHeight / 2))  screen->Print("Play Again?", (ScreenWidth / 2) + 25, (ScreenHeight / 2) + 8, 0xffffff);
			else if (mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2 + 30) + 20 && mousey >= (ScreenHeight / 2 + 30)) screen->Print("Back To Main Menu", (ScreenWidth / 2) + 25, (ScreenHeight / 2) + 38, 0xffffff);

			//--- Buttons Detector With A Mouse ---
			if (mouse_pressed == 1 && mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2) + 20 && mousey >= (ScreenHeight / 2)) mouse_pressed = 0, Current_gm = Game_gameplay, SaveScore = 0;
			else if (mouse_pressed == 1 && mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2 + 30) + 20 && mousey >= (ScreenHeight / 2 + 30)) mouse_pressed = 0, Current_gm = Game_menu, SaveScore = 0;
			else mouse_pressed = 0;
		}
		else if (Current_gm == Game_shop)
		{
			game.frame++;
			screen->Clear(0);
			int halfX = ScreenWidth / 2, halfY = ScreenHeight / 2;

			//--- Background ---
			for (int x = 0; x < ScreenWidth; x += 64)
			{
				for (int y = 0; y < ScreenHeight; y += 64) brownBg.Draw(screen, x, y);
			}

			//--- Printing Data ---
			char text[128];
			char PlayerCoinsText[128];
			sprintf(PlayerCoinsText, "Coins: %d", player.coins);
			sprintf(text, "This is Shop, click buttons or skins to upgrade/equip.");
			screen->Print(text, 5, 5, 0xffffff);
			screen->Print(PlayerCoinsText, 5, 20, 0xffff00);
			screen->Print("SHOP", ScreenWidth / 2, 50, 0xffffff);
			//sprintf(text, "This is Shop, click buttons or skins to upgrade/equip. % d\n", mouse_pressed);

			//--- Sprite Frame Changing ---
			firstSpriteShop.SetFrame(game.frame / 10 % 10);
			secondSpriteShop.SetFrame(game.frame / 10 % 10);
			thirdSpriteShop.SetFrame(game.frame / 10 % 10);
			fourthSpriteShop.SetFrame(game.frame / 10 % 10);
			scoreBonus.SetFrame(game.frame % 17);
			timeBonus.SetFrame(game.frame % 17);
			shieldBonus.SetFrame(game.frame % 17);

			//--- Back Button ---
			backToMenuButtom.Draw(screen, halfX, halfY + 180);
			if (mouse_pressed == 1 && mousex <= halfX + 20 && mousex >= halfX && mousey <= (halfY + 180) + 20 && mousey >= (halfY + 180)) mouse_pressed = 0, Current_gm = Game_menu;
			else if (mousex <= halfX + 20 && mousex >= halfX && mousey <= (halfY + 180) + 20 && mousey >= (halfY + 180))
			{
				screen->Print("Back To Main Menu", halfX + 25, (halfY + 180) + 8, 0xffffff);
				if (menuSounds.op[0] == 0)
				{
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
					memset(menuSounds.op, 0, sizeof(menuSounds.op));
					menuSounds.op[0] = 1;
				}
			}
			else memset(menuSounds.op, 0, sizeof(menuSounds.op));

			//--- First Skin Button ---
			firstSpriteShop.Draw(screen, halfX / 2, halfY - 96);
			if (shopData.skins[0] == 0)screen->Print("Price: 0", halfX / 2, halfY - 96 + 35, 0xffff00);
			else screen->Print("Ninja Frog", halfX / 2 - 10, halfY - 96 + 35, 0x00ff00);
			if (mouse_pressed == 0 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY - 96 + 32 && mousey >= halfY - 96)
			{
				if (shopData.skins[0] == 0) screen->Print("Buy?", halfX / 2 + 6, halfY - 96 - 6, 0xffffff);
				else if (shopData.skins[0] == 1) screen->Print("Equip?", halfX / 2 + 2, halfY - 96 - 6, 0xffffff);
				else screen->Print("Equiped", halfX / 2, halfY - 96 - 6, 0xffffff);
			}
			else if (mouse_pressed == 1 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY - 96 + 32 && mousey >= halfY - 96)
			{
				if (player.coins >= 0 && shopData.skins[0] <= 0)
				{
					shopData.skins[0] = 2;
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 0) shopData.skins[i] = 1;
					player.coins -= 0;
				}
				else if (shopData.skins[0] >= 1)
				{
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 0) shopData.skins[i] = 1;
					shopData.skins[0] = 2;
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
				}
			}
			//--- Second Skin Button ---
			secondSpriteShop.Draw(screen, halfX / 2, halfY - 32);
			if (shopData.skins[1] == 0)screen->Print("Price: 50", halfX / 2, halfY - 32 + 35, 0xffff00);
			else screen->Print("Mask Dude", halfX / 2 - 10, halfY - 32 + 35, 0xffa500);
			if (mouse_pressed == 0 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY - 32 + 32 && mousey >= halfY - 32)
			{
				if (shopData.skins[1] == 0) screen->Print("Buy?", halfX / 2 + 6, halfY - 32 - 6, 0xffffff);
				else if (shopData.skins[1] == 1) screen->Print("Equip?", halfX / 2 + 2, halfY - 32 - 6, 0xffffff);
				else screen->Print("Equiped", halfX / 2, halfY - 32 - 6, 0xffffff);
			}
			else if (mouse_pressed == 1 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY - 32 + 32 && mousey >= halfY - 32)
			{
				if (player.coins >= 50 && shopData.skins[1] <= 0)
				{
					shopData.skins[1] = 2;
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 1) shopData.skins[i] = 1;
					player.coins -= 50;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
				else if (shopData.skins[1] >= 1)
				{
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 1) shopData.skins[i] = 1;
					shopData.skins[1] = 2;
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
				}
			}
			//--- Third Skin Button ---
			thirdSpriteShop.Draw(screen, halfX / 2, halfY + 32);
			if (shopData.skins[2] == 0)screen->Print("Price: 100", halfX / 2, halfY + 32 + 35, 0xffff00);
			else screen->Print("Pink Man", halfX / 2 - 10, halfY + 32 + 35, 0xee82ee);
			if (mouse_pressed == 0 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY + 32 + 32 && mousey >= halfY + 32)
			{
				if (shopData.skins[2] == 0)screen->Print("Buy?", halfX / 2 + 6, halfY + 32 - 6, 0xffffff);
				else if (shopData.skins[2] == 1)screen->Print("Equip?", halfX / 2 + 2, halfY + 32 - 6, 0xffffff);
				else screen->Print("Equiped", halfX / 2, halfY + 32 - 6, 0xffffff);
			}
			else if (mouse_pressed == 1 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY + 32 + 32 && mousey >= halfY + 32)
			{
				if (player.coins >= 100 && shopData.skins[2] <= 0)
				{
					shopData.skins[2] = 2;
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 2) shopData.skins[i] = 1;
					player.coins -= 100;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
				else if (shopData.skins[2] >= 1)
				{
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 2) shopData.skins[i] = 1;
					shopData.skins[2] = 2;
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
				}
			}
			//--- Fourth Skin Button ---
			fourthSpriteShop.Draw(screen, halfX / 2, halfY + 96 );
			if (shopData.skins[3] == 0)screen->Print("Price: 200", halfX / 2, halfY + 96 + 35, 0xffff00);
			else screen->Print("Virtual Guy", halfX / 2 - 10, halfY + 96 + 35, 0x19a2de);
			if (mouse_pressed == 0 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY + 96 + 32 && mousey >= halfY + 96)
			{
				if (shopData.skins[3] == 0) screen->Print("Buy?", halfX / 2 + 6, halfY + 96 - 6, 0xffffff);
				else if (shopData.skins[3] == 1)screen->Print("Equip?", halfX / 2 + 2, halfY + 96 - 6, 0xffffff);
				else screen->Print("Equiped", halfX / 2, halfY + 96 - 6, 0xffffff);
			}
			else if (mouse_pressed == 1 && mousex <= halfX / 2 + 32 && mousex >= halfX / 2 && mousey <= halfY + 96 + 32 && mousey >= halfY + 96)
			{
				if (player.coins >= 200 && shopData.skins[3] <= 0)
				{
					shopData.skins[3] = 2;
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 3) shopData.skins[i] = 1;
					player.coins -= 200;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
				else if (shopData.skins[3] >= 1)
				{
					for (int i = 0; i < 4; i++) if (shopData.skins[i] >= 1 && i != 3) shopData.skins[i] = 1;
					shopData.skins[3] = 2;
					PlaySound("assets/sounds/BlipSelect.wav", NULL, SND_ASYNC);
				}
			}
			
			//--- Declaring Texts For Each Upgrade ---
			char speedLevel[128];
			char speedLevelCost[128];
			sprintf(speedLevel, "Player speed: %d level", shopData.speedLvl);
			sprintf(speedLevelCost, "Upgrade? %d coins", shopData.speedLvl * 50);
			char startingJumps[128];
			char startingJumpsCost[128];
			sprintf(startingJumps, "Starting jumps: %d level", shopData.startJumpLvl);
			sprintf(startingJumpsCost, "Upgrade? %d coins", shopData.startJumpLvl * 50);
			char bonusJump[128];
			char bonusJumpCost[128];
			sprintf(bonusJump, "Bonus jumps: %d level", shopData.bonusJumpLvl);
			sprintf(bonusJumpCost, "Upgrade? %d coins", shopData.bonusJumpLvl * 50);
			char bonusScore[128];
			char bonusScoreCost[128];
			sprintf(bonusScore, "Bonus score: %d level", shopData.bonusScoreLvl);
			sprintf(bonusScoreCost, "Upgrade? %d coins", shopData.bonusScoreLvl * 50);
			char shieldDuration[128];
			char shieldDurationCost[128];
			sprintf(shieldDuration, "Shield duration: %d level", shopData.bonusShieldTimeLvl);
			sprintf(shieldDurationCost, "Upgrade? %d coins", shopData.bonusShieldTimeLvl * 50);

			//--- Text And Upgrade System For The Player Movement Speed ---
			screen->Print(speedLevel, halfX + 100, halfY - 60, 0xffffff);
			plusButtom.Draw(screen, halfX + 250, halfY - 65);
			if (mousex <= halfX + 250 + 20 && mousex >= halfX + 250 && mousey <= halfY - 65 + 18 && mousey >= halfY - 65)
			{
				if (shopData.speedLvl < 5) screen->Print(speedLevelCost, halfX + 275, halfY - 60, 0xffff00);
				else screen->Print("MAX LEVEL", halfX + 275, halfY - 60, 0xff0000);

				if (mouse_pressed == 1 && player.coins >= shopData.speedLvl * 50 && shopData.speedLvl < 5)
				{
					player.coins -= shopData.speedLvl * 50;
					shopData.speedLvl++;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
			}
			//--- Text And Upgrade System For The Player Number Of Starting Jumps ---
			screen->Print(startingJumps, halfX + 100, halfY - 30, 0xffffff);
			plusButtom.Draw(screen, halfX + 250, halfY - 35);
			if (mousex <= halfX + 250 + 20 && mousex >= halfX + 250 && mousey <= halfY - 35 + 18 && mousey >= halfY - 35)
			{
				if (shopData.startJumpLvl < 5) screen->Print(startingJumpsCost, halfX + 275, halfY - 30, 0xffff00);
				else screen->Print("MAX LEVEL", halfX + 275, halfY - 30, 0xff0000);

				if (mouse_pressed == 1 && player.coins >= shopData.startJumpLvl * 50 && shopData.startJumpLvl < 5)
				{
					player.coins -= shopData.startJumpLvl * 50;
					shopData.startJumpLvl++;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
			}
			//--- Text And Upgrade System For The Jump Bonus (Banana) ---
			screen->Print(bonusJump, halfX + 100, halfY, 0xffffff);
			plusButtom.Draw(screen, halfX + 250, halfY - 5);
			if (mousex <= halfX + 250 + 20 && mousex >= halfX + 250 && mousey <= halfY - 5 + 18 && mousey >= halfY - 5)
			{
				if (shopData.bonusJumpLvl < 5) screen->Print(bonusJumpCost, halfX + 275, halfY, 0xffff00);
				else screen->Print("MAX LEVEL", halfX + 275, halfY, 0xff0000);

				if (mouse_pressed == 1 && player.coins >= shopData.bonusJumpLvl * 50 && shopData.bonusJumpLvl < 5)
				{
					player.coins -= shopData.bonusJumpLvl * 50;
					shopData.bonusJumpLvl++;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
			}
			//--- Text And Upgrade System For The Jump Bonus (Apple) ---
			screen->Print(bonusScore, halfX + 100, halfY + 30, 0xffffff);
			plusButtom.Draw(screen, halfX + 250, halfY + 25);
			if (mousex <= halfX + 250 + 20 && mousex >= halfX + 250 && mousey <= halfY + 25 + 18 && mousey >= halfY + 25)
			{
				if (shopData.bonusScoreLvl < 5) screen->Print(bonusScoreCost, halfX + 275, halfY + 30, 0xffff00);
				else screen->Print("MAX LEVEL", halfX + 275, halfY + 30, 0xff0000);

				if (mouse_pressed == 1 && player.coins >= shopData.bonusScoreLvl * 50 && shopData.bonusScoreLvl < 5)
				{
					player.coins -= shopData.bonusScoreLvl * 50;
					shopData.bonusScoreLvl++;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
			}
			//--- Text And Upgrade System For The Jump Bonus (Melon) ---
			screen->Print(shieldDuration, halfX + 100, halfY + 60, 0xffffff);
			plusButtom.Draw(screen, halfX + 250, halfY + 55);
			if (mousex <= halfX + 250 + 20 && mousex >= halfX + 250 && mousey <= halfY + 55 + 18 && mousey >= halfY + 55)
			{
				if (shopData.bonusShieldTimeLvl < 5) screen->Print(shieldDurationCost, halfX + 275, halfY + 60, 0xffff00);
				else screen->Print("MAX LEVEL", halfX + 275, halfY + 60, 0xff0000);

				if (mouse_pressed == 1 && player.coins >= shopData.bonusShieldTimeLvl * 50 && shopData.bonusShieldTimeLvl < 5)
				{
					player.coins -= shopData.bonusShieldTimeLvl * 50;
					shopData.bonusShieldTimeLvl++;
					PlaySound("assets/sounds/Buy.wav", NULL, SND_ASYNC);
				}
			}

			//--- Drawing Sprites ---
			scoreBonus.Draw(screen, halfX + 65, halfY + 20);
			timeBonus.Draw(screen, halfX + 65, halfY - 10);
			shieldBonus.Draw(screen, halfX + 65, halfY + 50);

			mouse_pressed = 0;
		}
		else if (Current_gm == Game_win)
		{
			screen->Clear(0);
			resetGame(game, shopData, player, scrBonus, jumpBonus, sdBonus, pig, bat, bee);

			//--- Saving Score ---
			if (player.score > 0) SaveScore = player.score;
			player.coins += player.score / 100;
			if (player.score > player.bestScore) player.bestScore = player.score;
			player.score = 0;

			//--- Printing Data ---
			char resultText[128];
			char coins[128];
			sprintf(resultText, "Congratulations, you won! Your score: %d", SaveScore);
			sprintf(coins, "That is %d coins! Plus 100 coins for winning!!!", SaveScore / 100);
			screen->Print(resultText, ScreenWidth / 2 - 120, ScreenHeight / 2 - 40, 0xffff00);
			screen->Print(coins, ScreenWidth / 2 - 130, ScreenHeight / 2 - 20, 0xffff00);

			//--- Drawing Buttons ---
			restartButtom.Draw(screen, ScreenWidth / 2, ScreenHeight / 2);
			backToMenuButtom.Draw(screen, ScreenWidth / 2, ScreenHeight / 2 + 30);

			//--- Buttons Texts Detector With A Mouse ---
			if (mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2) + 20 && mousey >= (ScreenHeight / 2))  screen->Print("Play Again?", (ScreenWidth / 2) + 25, (ScreenHeight / 2) + 8, 0xffffff);
			else if (mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2 + 30) + 20 && mousey >= (ScreenHeight / 2 + 30)) screen->Print("Back To Main Menu", (ScreenWidth / 2) + 25, (ScreenHeight / 2) + 38, 0xffffff);
			////--- Buttons Detector With A Mouse +100 coins for winning ---
			if (mouse_pressed == 1 && mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2) + 20 && mousey >= (ScreenHeight / 2)) mouse_pressed = 0, Current_gm = Game_gameplay, SaveScore = 0, player.coins += 100;
			else if (mouse_pressed == 1 && mousex <= (ScreenWidth / 2) + 20 && mousex >= (ScreenWidth / 2) && mousey <= (ScreenHeight / 2 + 30) + 20 && mousey >= (ScreenHeight / 2 + 30)) mouse_pressed = 0, Current_gm = Game_menu, SaveScore = 0, player.coins += 100;
			else mouse_pressed = 0;
		}
	} 

	void collisions(GameData& game, Player& player, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee)
	{
		for (int i = 0; i < pig.size(); i++)
		{
			if (player.shieldIsActive != true && player.X - pig[i].x >= -25 && player.X - pig[i].x <= 25 && player.Y - pig[i].y >= -30 && player.Y - pig[i].y <= 30) //player.Y - pig[i].y >= -30
			{
				PlaySound("assets/sounds/Death.wav", NULL, SND_ASYNC);
				sprintf(game.DeathMessage, "You died because angry pig ate you! :O");
				Current_gm = Game_over;
				printf("Collision with a pig.\n");
			}

			if (pig[i].x < -40 && pig[i].isMovingLeft == true) //colision with borders
			{
				if (rand() % 2 == 0)
				{
					pig[i].isMovingLeft = false;
					pig[i].x = rand() % 200 - 250;
					pig[i].speed = rand() % 3 + 3;
				}
				else
				{
					pig[i].isMovingLeft = true;
					pig[i].x = rand() % 200 + 850;
					pig[i].speed = rand() % 3 + 3;
				}
			}
			else if (pig[i].x > 840 && pig[i].isMovingLeft == false)
			{
				if (rand() % 2 == 0)
				{
					pig[i].isMovingLeft = false;
					pig[i].x = rand() % 200 - 250;
					pig[i].speed = rand() % 3 + 3;
				}
				else
				{
					pig[i].isMovingLeft = true;
					pig[i].x = rand() % 200 + 850;
					pig[i].speed = rand() % 3 + 3;
				}
			}
		}

		for (int i = 0; i < bat.size(); i++)
		{
			if (player.shieldIsActive != true && player.X - bat[i].x >= -30 && player.X - bat[i].x <= 30 && player.Y - bat[i].y >= -25 && player.Y - bat[i].y <= 25)
			{
				PlaySound("assets/sounds/Death.wav", NULL, SND_ASYNC);
				sprintf(game.DeathMessage, "You died because flying bat ate you! :O");
				Current_gm = Game_over;
				printf("Collision with a bat.\n");
			}

			if (bat[i].x < -40 && bat[i].isMovingLeft == true) //colision with borders
			{
				if (rand() % 2 == 0)
				{
					bat[i].isMovingLeft = false;
					bat[i].x = rand() % 200 - 300;
					bat[i].y = rand() % 420 + 32;
					bat[i].speed = rand() % 3 + 3;
				}
				else
				{
					bat[i].isMovingLeft = true;
					bat[i].x = rand() % 300 + 800;
					bat[i].y = rand() % 420 + 32;
					bat[i].speed = rand() % 3 + 3;
				}
			}
			else if (bat[i].x > 840 && bat[i].isMovingLeft == false)
			{
				if (rand() % 2 == 0)
				{
					bat[i].isMovingLeft = false;
					bat[i].x = rand() % 200 - 300;
					bat[i].y = rand() % 420 + 32;
					bat[i].speed = rand() % 3 + 3;
				}
				else
				{
					bat[i].isMovingLeft = true;
					bat[i].x = rand() % 300 + 800;
					bat[i].y = rand() % 420 + 32;
					bat[i].speed = rand() % 3 + 3;
				}
			}
		}

		for (int i = 0; i < bee.size(); i++)
		{
			if (player.shieldIsActive != true && player.X - bee[i].x >= -30 && player.X - bee[i].x <= 30 && player.Y - bee[i].y >= -30 && player.Y - bee[i].y <= 30)
			{
				sprintf(game.DeathMessage, "You died because flying bee ate you! :O");
				Current_gm = Game_over;
				printf("Collision with a bee.\n");

				PlaySound("assets/sounds/Death.wav", NULL, SND_ASYNC);
			}

			if (bee[i].x < -40) //colision with borders
			{
				bee.pop_back();
			}
		}

		for (int i = 0; i < scrBonus.size(); i++)
		{
			if (player.X - scrBonus[i].x >= -25 && player.X - scrBonus[i].x <= 25 && player.Y - scrBonus[i].y >= -16 && player.Y - scrBonus[i].y <= 16)
			{
				PlaySound("assets/sounds/Apple.wav", NULL, SND_ASYNC);
				printf("Collision with a apple.\n");
				player.score += shopData.bonusScoreLvl * 100;

				scrBonus[i].x = rand() % 736 + 32;
				if (rand() % 3 == 0) scrBonus[i].y = 480;
				else if (rand() % 3 == 1) scrBonus[i].y = lpY - 32;
				else scrBonus[i].y = lpwhY - 32;
			}
		}

		for (int i = 0; i < jumpBonus.size(); i++)
		{
			if (player.X - jumpBonus[i].x >= -25 && player.X - jumpBonus[i].x <= 25 && player.Y - jumpBonus[i].y >= -16 && player.Y - jumpBonus[i].y <= 16)
			{
				PlaySound("assets/sounds/Banana.wav", NULL, SND_ASYNC);
				printf("Collision with a banana.\n");
				player.score += 150;
				player.jumpLeft = player.jumpLeft + 10 + shopData.bonusJumpLvl * 5 ;

				jumpBonus[i].x = rand() % 736 + 32;
				if (rand() % 3 == 0) jumpBonus[i].y = 480;
				else if (rand() % 3 == 1) jumpBonus[i].y = lpY - 32;
				else jumpBonus[i].y = lpwhY - 32;
			}
		}

		for (int i = 0; i < sdBonus.size(); i++)
		{
			if (sdBonus[i].hasCooldown != true && player.X - sdBonus[i].x >= -25 && player.X - sdBonus[i].x <= 25 && player.Y - sdBonus[i].y >= -16 && player.Y - sdBonus[i].y <= 16)
			{
				PlaySound("assets/sounds/Melon.wav", NULL, SND_ASYNC);
				printf("Collision with a melon.\n");
				player.score += 50;

				player.shieldIsActive = true;
				sdBonus[i].timeLeft = 60 * (2 + shopData.bonusShieldTimeLvl);
				sdBonus[i].couldown = 60 * 2;
				sdBonus[i].hasCooldown = true;

				sdBonus[i].x = rand() % 736 + 32;
				sdBonus[i].x = rand() % 736 + 32;
				if (rand() % 3 == 0) sdBonus[i].y = 480;
				else if (rand() % 3 == 1) sdBonus[i].y = lpY - 32;
				else sdBonus[i].y = lpwhY - 32;
			}
		}
	}
	void playerJumps(Player& player)
	{
		if (player.X + 32 > lpX && player.X + 32 < lpX + 235 - 20 && player.Y + 32 < lpY + 30 && player.Y + 32 > lpY && player.ground >= 2 && player.speed >= 0)
		{
			player.Y = ScreenHeight / 2 - 32;
			if (player.ground <= 2)
			{
				player.ground = 3;
				player.speed = -(player.speed + 5);
			}
			else player.speed = -player.speed;
			player.limitY = 450 - 32;
			player.jumpLeft--;
			PlaySound("assets/sounds/Jump.wav", NULL, SND_ASYNC);
		}
		else if (player.X + 32 > 47 && player.X + 32 < 0 + 235 + 25 && player.Y + 32 < ScreenHeight / 2 + 30 && player.Y + 32 > ScreenHeight / 2 && player.ground >= 2 && player.speed >= 0)
		{
			player.Y = ScreenHeight / 2 - 32;
			if (player.ground <= 2)
			{
				player.ground = 3;
				player.speed = -(player.speed + 5);
			}
			else player.speed = -player.speed;
			player.limitY = 450 - 32;
			player.jumpLeft--;
			PlaySound("assets/sounds/Jump.wav", NULL, SND_ASYNC);
		}
		else if (player.X + 32 > lpwhX && player.X < lpwhX + 235 && player.Y + 32 < lpwhY + 30 && player.Y + 32 > lpwhY && player.speed >= 0)
		{
			if (player.X + 16 >= lpwhX + 92 && player.X + 16 <= lpwhX + 139) {}
			else
			{
				player.Y = ScreenHeight / 2 + 110 - 32;
				if (player.ground <= 1)
				{
					player.speed = -(player.speed + 10);
				}
				else player.speed = -player.speed;
				player.ground = 2;
				player.limitY = 350; //394
				player.jumpLeft--;
				PlaySound("assets/sounds/Jump.wav", NULL, SND_ASYNC);
			}
		}
		else if (player.Y > (512 - 32))
		{
			player.Y = 512 - 32;
			player.speed = -player.speed;
			player.jumpLeft--;
			player.ground = 1;
			player.limitY = 180; //was 200

			PlaySound("assets/sounds/Jump.wav", NULL, SND_ASYNC);
		}

		if (player.Y < 512 - 32 - player.limitY) player.speed = 3;
	}
	void resetGame(GameData& game, ShopData shopData, Player& player, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee)
	{
		game.timer = 120;
		game.frame = 0;
		player.X = 0, player.Y = 300;
		player.jumpLeft = 10 + shopData.startJumpLvl * 10;
		player.shieldIsActive = false;

		for (int i = 0; i < scrBonus.size(); i++)scrBonus.pop_back();
		for (int i = 0; i < jumpBonus.size(); i++)jumpBonus.pop_back();
		for (int i = 0; i < sdBonus.size(); i++)sdBonus.pop_back();
		for (int i = 0; i < pig.size(); i++)pig.pop_back();
		for (int i = 0; i < bat.size(); i++)bat.pop_back();
		for (int i = 0; i < bee.size(); i++)bee.pop_back();
	}
	void spawnBonuses(GameData game, vector<Bonus>& scrBonus, vector<Bonus>& jumpBonus, vector<Bonus>& sdBonus)
	{
		switch (game.frame) {
		case 2 * 60:
			jumpBonus.push_back(Bonus());
			break;
		case 5 * 60:
			sdBonus.push_back(Bonus());
			break;
		case 10 * 60:
			scrBonus.push_back(Bonus());
			break;
		case 20 * 60:
			scrBonus.push_back(Bonus());
			break;
		case 40 * 60:
			jumpBonus.push_back(Bonus());
			break;
		default:
			break;
		}
	}
	void spawnEnemies(GameData game, vector<Enemy>& pig, vector<Enemy>& bat, vector<Enemy>& bee)
	{
		switch (game.frame) {
		case 5 * 60:
			pig.push_back(Enemy());
			pig[0].x = -100, pig[0].isMovingLeft = false;
			break;
		case 10 * 60:
			bat.push_back(Enemy());
			bat[0].y = rand() % 420 + 32;
			break;
		case 15 * 60:
			bee.push_back(Enemy());
			break;
		case 20 * 60:
			pig.push_back(Enemy());
			break;
		case 30 * 60:
			bee.push_back(Enemy());
			break;
		case 40 * 60:
			bat.push_back(Enemy());
			bat[1].y = rand() % 420 + 32;
			break;
		case 60 * 60:
			pig.push_back(Enemy());
			break;
		case 70 * 60:
			bee.push_back(Enemy());
			break;
		case 80 * 60:
			bee.push_back(Enemy());
			break;
		case 90 * 60:
			bat.push_back(Enemy());
			bat[2].y = rand() % 420 + 32;
			break;
		case 115 * 60:
			bee.push_back(Enemy());
			break;
		default:
			break;
		}
	}
};